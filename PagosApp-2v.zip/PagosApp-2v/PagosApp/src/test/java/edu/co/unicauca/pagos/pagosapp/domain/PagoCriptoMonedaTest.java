/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.co.unicauca.pagos.pagosapp.domain;

import co.edu.unicauca.pagos.p.plug.in.PagoCriptoMoneda;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Jhonatan
 */
public class PagoCriptoMonedaTest {
    
    @Test
    public void testcreatePagoCriptoMoneda() {
        PagoCriptoMoneda pago = new PagoCriptoMoneda("1A2B3C4D5E");
        assertEquals(pago.getBilletera(),"1A2B3C4D5E");
    }
    
    @Test
    void testvalidarCuentaValida() {
        PagoCriptoMoneda pago = new PagoCriptoMoneda("1A2B3C4D5E");
        assertTrue(pago.validar());
    }
    
    @Test
    public void testvalidarPagoCriptoMoneda() {
        PagoCriptoMoneda pago = new PagoCriptoMoneda("1A2B3C4D5E");
        assertDoesNotThrow(pago::procesar);
    }
    
    @Test
    public void testProcesarPagoInvalido() {
    PagoCriptoMoneda pago = new PagoCriptoMoneda("1A2B3C4");
    assertFalse(pago.validar());
    }
    
}
